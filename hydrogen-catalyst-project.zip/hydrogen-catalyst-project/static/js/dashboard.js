/**
 * Heterogeneous Catalyst Discovery Dashboard
 * Frontend JavaScript client using Fetch API and Chart.js
 */

let comparisonChart = null;
let featureChart = null;
let allCatalystsData = [];
let currentComparisonData = null;

// Initialize on DOM Load
document.addEventListener("DOMContentLoaded", () => {
  initDashboard();
  setupEventListeners();
});

async function initDashboard() {
  showLoading(true);
  try {
    await Promise.all([
      fetchStatusAndMetrics(),
      fetchBestCatalyst(),
      fetchCatalysts(),
      fetchComparisonChart()
    ]);
  } catch (error) {
    console.error("Dashboard initialization error:", error);
    showNotification("Failed to load dashboard data: " + error.message, "error");
  } finally {
    showLoading(false);
  }
}

function setupEventListeners() {
  // Search bar filter
  const searchInput = document.getElementById("catalystSearch");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      filterCatalystCards(e.target.value);
    });
  }

  // Dual chart toggle
  const toggleBtn = document.getElementById("toggleDualChartBtn");
  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      toggleChartMode();
    });
  }

  // Custom Simulator Form
  const simForm = document.getElementById("customSimulatorForm");
  if (simForm) {
    simForm.addEventListener("submit", handleCustomSimulation);
  }

  // Upload Dataset Form
  const uploadForm = document.getElementById("datasetUploadForm");
  if (uploadForm) {
    uploadForm.addEventListener("submit", handleDatasetUpload);
  }

  // Kaggle Download Form
  const kaggleForm = document.getElementById("kaggleDownloadForm");
  if (kaggleForm) {
    kaggleForm.addEventListener("submit", handleKaggleDownload);
  }

  // Modal close
  const modalOverlay = document.getElementById("catalystModal");
  if (modalOverlay) {
    modalOverlay.addEventListener("click", (e) => {
      if (e.target === modalOverlay) closeModal();
    });
  }
}

// ==========================================
// API Fetch Handlers
// ==========================================

async function fetchStatusAndMetrics() {
  const res = await fetch("/api/status");
  const data = await res.json();
  if (data.status !== "success") throw new Error(data.message);

  // Update Stats Cards
  document.getElementById("totalRecordsVal").innerText = data.dataset.total_records;
  document.getElementById("totalCatalystsVal").innerText = data.dataset.total_catalysts;
  document.getElementById("targetUnitVal").innerText = data.dataset.target_unit;
  
  // Model performance
  const perf = data.model_performance;
  document.getElementById("activeModelVal").innerText = perf.active_model;
  document.getElementById("r2ScoreVal").innerText = (perf.r2_score * 100).toFixed(1) + "%";
  document.getElementById("maeVal").innerText = `${perf.mae} ${perf.target_unit}`;
  document.getElementById("rmseVal").innerText = `${perf.rmse} ${perf.target_unit}`;

  // Render Feature Importances Chart
  renderFeatureImportanceChart(data.top_features);

  // Kaggle status badge
  const kaggleBadge = document.getElementById("kaggleStatusBadge");
  if (kaggleBadge) {
    const auth = data.dataset.kaggle_integration.authenticated;
    kaggleBadge.className = auth ? "badge badge-success" : "badge badge-warning";
    kaggleBadge.innerText = auth ? "Kaggle API Connected" : "Local CSV Active (Kaggle Optional)";
  }
}

async function fetchBestCatalyst() {
  const res = await fetch("/api/best-catalyst");
  const data = await res.json();
  if (data.status !== "success") throw new Error(data.message);

  const best = data.best_catalyst;
  document.getElementById("bannerBestName").innerText = best.catalyst_name;
  document.getElementById("bannerBestRate").innerText = best.predicted_h2_rate;
  document.getElementById("bannerBestUnit").innerText = best.target_unit;
  document.getElementById("bannerBestSupport").innerText = best.support_material;
  document.getElementById("bannerBestRank").innerText = `#${best.ranking} of ${best.total_catalysts}`;

  // Difference vs average and runner up
  const diffAvgEl = document.getElementById("bannerDiffAvg");
  if (diffAvgEl) {
    diffAvgEl.innerText = `+${best.pct_difference_vs_average}% vs Avg (${best.average_all_catalysts_rate} ${best.target_unit})`;
  }
  const diffRunnerEl = document.getElementById("bannerDiffRunner");
  if (diffRunnerEl && best.runner_up_name) {
    diffRunnerEl.innerText = `+${best.pct_difference_vs_runner_up}% vs ${best.runner_up_name}`;
  }
}

async function fetchCatalysts() {
  const res = await fetch("/api/catalysts");
  const data = await res.json();
  if (data.status !== "success") throw new Error(data.message);

  allCatalystsData = data.catalysts;
  renderCatalystCards(allCatalystsData);
  updateCandidateSpotlight(allCatalystsData);
}

async function fetchComparisonChart() {
  const res = await fetch("/api/compare");
  const data = await res.json();
  if (data.status !== "success") throw new Error(data.message);

  currentComparisonData = data.data;
  renderComparisonChart(currentComparisonData, false);
}

// ==========================================
// Rendering Functions
// ==========================================

function renderCatalystCards(catalysts) {
  const container = document.getElementById("catalystCardsContainer");
  if (!container) return;

  container.innerHTML = "";
  if (catalysts.length === 0) {
    container.innerHTML = `<div class="empty-state">No matching catalysts found.</div>`;
    return;
  }

  catalysts.forEach((cat) => {
    const card = document.createElement("div");
    card.className = `catalyst-card ${cat.ranking === 1 ? "is-best" : ""} ${cat.is_primary_candidate ? "is-primary" : ""}`;
    card.onclick = () => openCatalystDetails(cat.catalyst_name);

    let rankClass = "card-rank";
    if (cat.ranking === 1) rankClass += " rank-1";
    else if (cat.ranking === 2) rankClass += " rank-2";
    else if (cat.ranking === 3) rankClass += " rank-3";

    card.innerHTML = `
      <div class="card-top">
        <span class="${rankClass}">RANK #${cat.ranking}</span>
        ${cat.is_primary_candidate ? '<span class="card-candidate-tag">PRIMARY CANDIDATE</span>' : ""}
      </div>
      <div class="card-cat-name">${cat.catalyst_name}</div>
      <div class="card-support">Support: ${cat.support_material}</div>
      <div class="card-rate-box">
        <div class="rate-label">Predicted H₂ Production Rate</div>
        <div class="rate-number">
          ${cat.predicted_h2_rate}
          <span class="rate-unit">${cat.target_unit}</span>
        </div>
      </div>
      <div class="card-footer">
        <span>Exp. Records: <strong>${cat.record_count}</strong></span>
        <span>Measured Mean: <strong>${cat.measured_h2_rate_mean || 'N/A'}</strong></span>
      </div>
    `;
    container.appendChild(card);
  });
}

function updateCandidateSpotlight(catalysts) {
  const cand = catalysts.find(c => c.catalyst_name === "Pt-Ru-Ni/C");
  if (!cand) return;

  const spotlightName = document.getElementById("spotlightName");
  const spotlightRank = document.getElementById("spotlightRank");
  const spotlightPred = document.getElementById("spotlightPred");
  const spotlightMeasured = document.getElementById("spotlightMeasured");
  const spotlightNote = document.getElementById("spotlightNote");

  if (spotlightName) spotlightName.innerText = cand.catalyst_name;
  if (spotlightRank) spotlightRank.innerText = `#${cand.ranking} of ${cand.total_catalysts}`;
  if (spotlightPred) spotlightPred.innerText = `${cand.predicted_h2_rate} ${cand.target_unit}`;
  if (spotlightMeasured) spotlightMeasured.innerText = `${cand.measured_h2_rate_mean || 'N/A'} ${cand.target_unit}`;
  if (spotlightNote) {
    spotlightNote.innerText = `Evaluated honestly from ${cand.record_count} experimental literature records without artificial score inflation. Model-derived ranking is based on multi-metal synergy and physical surface reaction features.`;
  }
}

function filterCatalystCards(query) {
  const q = query.trim().toLowerCase();
  if (!q) {
    renderCatalystCards(allCatalystsData);
    return;
  }
  const filtered = allCatalystsData.filter(c => 
    c.catalyst_name.toLowerCase().includes(q) ||
    c.support_material.toLowerCase().includes(q)
  );
  renderCatalystCards(filtered);
}

// ==========================================
// Chart.js Visualizations
// ==========================================

let isDualMode = false;

function toggleChartMode() {
  if (!currentComparisonData) return;
  isDualMode = !isDualMode;
  const btn = document.getElementById("toggleDualChartBtn");
  if (btn) {
    btn.innerText = isDualMode ? "Show Predicted Rates Only" : "Compare Predicted vs Measured";
  }
  renderComparisonChart(currentComparisonData, isDualMode);
}

function renderComparisonChart(data, dualMode = false) {
  const ctx = document.getElementById("comparisonChartCanvas")?.getContext("2d");
  if (!ctx) return;

  if (comparisonChart) comparisonChart.destroy();

  const datasets = [
    {
      label: `Predicted H₂ Production (${data.target_unit})`,
      data: data.predicted_rates,
      backgroundColor: data.bar_colors,
      borderColor: data.border_colors,
      borderWidth: 1.5,
      borderRadius: 6
    }
  ];

  if (dualMode) {
    datasets.push({
      label: `Measured Mean H₂ Production (${data.target_unit})`,
      data: data.measured_rates,
      backgroundColor: "rgba(245, 158, 11, 0.7)",
      borderColor: "#d97706",
      borderWidth: 1.5,
      borderRadius: 6
    });
  }

  comparisonChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: data.labels,
      datasets: datasets
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: dualMode,
          labels: { color: "#94a3b8", font: { family: "Inter", size: 12 } }
        },
        tooltip: {
          backgroundColor: "#1e293b",
          titleColor: "#f8fafc",
          bodyColor: "#cbd5e1",
          borderColor: "rgba(255, 255, 255, 0.1)",
          borderWidth: 1,
          padding: 12,
          callbacks: {
            label: function (context) {
              return ` ${context.dataset.label}: ${context.raw} ${data.target_unit}`;
            }
          }
        }
      },
      scales: {
        x: {
          ticks: { color: "#94a3b8", font: { family: "JetBrains Mono", size: 11 } },
          grid: { display: false }
        },
        y: {
          title: {
            display: true,
            text: `Hydrogen Production Rate (${data.target_unit})`,
            color: "#94a3b8",
            font: { family: "Inter", size: 12, weight: 600 }
          },
          ticks: { color: "#94a3b8" },
          grid: { color: "rgba(255, 255, 255, 0.05)" }
        }
      }
    }
  });
}

function renderFeatureImportanceChart(features) {
  const ctx = document.getElementById("featureChartCanvas")?.getContext("2d");
  if (!ctx || !features || features.length === 0) return;

  if (featureChart) featureChart.destroy();

  const labels = features.map(f => f.feature);
  const values = features.map(f => f.importance);

  featureChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Relative Importance",
        data: values,
        backgroundColor: "rgba(16, 185, 129, 0.75)",
        borderColor: "#059669",
        borderWidth: 1,
        borderRadius: 4
      }]
    },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => ` Importance: ${(ctx.raw * 100).toFixed(1)}%`
          }
        }
      },
      scales: {
        x: {
          ticks: { color: "#94a3b8" },
          grid: { color: "rgba(255, 255, 255, 0.05)" }
        },
        y: {
          ticks: { color: "#cbd5e1", font: { size: 10 } },
          grid: { display: false }
        }
      }
    }
  });
}

// ==========================================
// Modal & Catalyst Details
// ==========================================

async function openCatalystDetails(catalystName) {
  const modal = document.getElementById("catalystModal");
  if (!modal) return;

  modal.classList.add("active");
  const modalBody = document.getElementById("modalBodyContent");
  modalBody.innerHTML = `<div class="loading-spinner">Loading catalyst details...</div>`;

  try {
    const res = await fetch(`/api/catalyst/${encodeURIComponent(catalystName)}`);
    const data = await res.json();
    if (data.status !== "success") throw new Error(data.message);

    const c = data.catalyst;
    const metals = c.metal_loadings;

    let candidateAlertHtml = "";
    if (c.candidate_analysis) {
      candidateAlertHtml = `
        <div class="candidate-alert" style="background: rgba(139, 92, 246, 0.15); border: 1px solid #8b5cf6; padding: 1rem; border-radius: 8px; margin-bottom: 1.25rem;">
          <h4 style="color: #c4b5fd; margin-bottom: 0.35rem; display:flex; align-items:center; gap:0.5rem;">
            <span>🔬</span> Primary Candidate Analysis: Pt-Ru-Ni/C
          </h4>
          <p style="font-size: 0.85rem; color: #e2e8f0;">${c.candidate_analysis.status_note}</p>
        </div>
      `;
    }

    let recordsRows = "";
    if (c.experimental_records && c.experimental_records.length > 0) {
      recordsRows = c.experimental_records.map((r, idx) => `
        <tr>
          <td>#${idx + 1}</td>
          <td>${r.pt_wt}% Pt, ${r.ru_wt}% Ru, ${r.ni_wt}% Ni</td>
          <td>${r.support}</td>
          <td>${r.temperature} °C</td>
          <td>${r.bet_area} m²/g</td>
          <td>${r.particle_size} nm</td>
          <td><strong>${r.measured_rate}</strong> ${r.unit}</td>
          <td><code>${r.doi}</code></td>
        </tr>
      `).join("");
    }

    modalBody.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.25rem;">
        <div>
          <h2 style="font-size: 1.85rem; font-family: var(--font-mono);">${c.catalyst_name}</h2>
          <p style="color: var(--text-muted); font-size: 0.9rem;">Support Material: <strong>${c.support_material}</strong></p>
        </div>
        <div style="text-align:right;">
          <span class="card-rank rank-${c.ranking}" style="font-size:0.9rem; padding:0.4rem 0.8rem;">
            RANK #${c.ranking} OF ${c.total_catalysts}
          </span>
        </div>
      </div>

      ${candidateAlertHtml}

      <div class="stats-grid" style="margin-bottom: 1.5rem;">
        <div class="stat-card">
          <div class="stat-title">Predicted H₂ Rate</div>
          <div class="stat-value" style="color:#34d399;">${c.predicted_h2_rate}</div>
          <div class="stat-sub">${c.target_unit}</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">Measured Mean</div>
          <div class="stat-value" style="color:#60a5fa;">${c.measured_h2_rate_mean || 'N/A'}</div>
          <div class="stat-sub">${c.target_unit} (Min: ${c.measured_h2_rate_min}, Max: ${c.measured_h2_rate_max})</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">Experimental Records</div>
          <div class="stat-value">${c.record_count}</div>
          <div class="stat-sub">Literature batches tested</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">Total Active Metal</div>
          <div class="stat-value">${metals.total_metal_wt_pct}%</div>
          <div class="stat-sub">Pt: ${metals.pt_wt_pct}%, Ru: ${metals.ru_wt_pct}%, Ni: ${metals.ni_wt_pct}%</div>
        </div>
      </div>

      <h3 style="font-size: 1.15rem; margin-bottom: 0.75rem;">Experimental Records & Literature Trials (${c.record_count})</h3>
      <div class="data-table-wrapper">
        <table class="data-table">
          <thead>
            <tr>
              <th>Trial</th>
              <th>Composition</th>
              <th>Support</th>
              <th>Temp</th>
              <th>BET Area</th>
              <th>Particle Size</th>
              <th>Measured H₂ Rate</th>
              <th>Reference DOI</th>
            </tr>
          </thead>
          <tbody>
            ${recordsRows}
          </tbody>
        </table>
      </div>
    `;
  } catch (error) {
    modalBody.innerHTML = `<div class="error-msg">Failed to load details: ${error.message}</div>`;
  }
}

function closeModal() {
  const modal = document.getElementById("catalystModal");
  if (modal) modal.classList.remove("active");
}

// ==========================================
// Interactive Simulator Form
// ==========================================

async function handleCustomSimulation(e) {
  e.preventDefault();
  const form = e.target;
  const payload = {
    catalyst_name: form.custom_name.value || "Custom Formulation",
    pt_loading_wt_pct: parseFloat(form.pt_wt.value) || 0.0,
    ru_loading_wt_pct: parseFloat(form.ru_wt.value) || 0.0,
    ni_loading_wt_pct: parseFloat(form.ni_wt.value) || 0.0,
    other_metal_wt_pct: parseFloat(form.other_wt.value) || 0.0,
    support_material: form.support.value,
    reaction_temperature_c: parseFloat(form.temperature.value) || 50.0,
    bet_surface_area_m2_g: parseFloat(form.bet_area.value) || 400.0,
    avg_particle_size_nm: parseFloat(form.particle_size.value) || 3.0,
    reactant_concentration_M: parseFloat(form.concentration.value) || 1.0,
    stirring_speed_rpm: parseFloat(form.stirring.value) || 800.0
  };

  const resultBox = document.getElementById("customSimResultBox");
  resultBox.innerHTML = "Predicting with trained ML model...";

  try {
    const res = await fetch("/api/predict-custom", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.status !== "success") throw new Error(data.message);

    const pred = data.prediction;
    resultBox.innerHTML = `
      <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10b981; padding: 1rem; border-radius: 8px;">
        <div style="font-size:0.8rem; text-transform:uppercase; color:#94a3b8; font-weight:600;">Predicted Production Rate</div>
        <div style="font-size: 1.85rem; font-weight:800; font-family:var(--font-mono); color:#34d399;">
          ${pred.predicted_h2_rate} <span style="font-size:1rem; color:#cbd5e1;">${pred.target_unit}</span>
        </div>
        <div style="font-size:0.8rem; color:#cbd5e1; margin-top:0.35rem;">
          Formulation: ${payload.pt_loading_wt_pct}% Pt, ${payload.ru_loading_wt_pct}% Ru, ${payload.ni_loading_wt_pct}% Ni on ${payload.support_material} at ${payload.reaction_temperature_c}°C
        </div>
      </div>
    `;
  } catch (error) {
    resultBox.innerHTML = `<div class="error-msg">Prediction failed: ${error.message}</div>`;
  }
}

// ==========================================
// Dataset Upload & Kaggle Handlers
// ==========================================

async function handleDatasetUpload(e) {
  e.preventDefault();
  const fileInput = document.getElementById("csvFileInput");
  if (!fileInput.files.length) {
    alert("Please select a CSV file to upload.");
    return;
  }

  const formData = new FormData();
  formData.append("file", fileInput.files[0]);

  const statusEl = document.getElementById("uploadStatusMsg");
  statusEl.innerText = "Inspecting columns, validating target, and retraining model...";

  try {
    const res = await fetch("/api/upload-dataset", {
      method: "POST",
      body: formData
    });
    const data = await res.json();
    if (data.status !== "success") {
      throw new Error(data.message);
    }
    statusEl.innerHTML = `<span style="color:#34d399;">✓ ${data.message}</span>`;
    await initDashboard();
  } catch (error) {
    statusEl.innerHTML = `<span style="color:#f43f5e;">✗ ${error.message}</span>`;
  }
}

async function handleKaggleDownload(e) {
  e.preventDefault();
  const slugInput = document.getElementById("kaggleSlugInput");
  const slug = slugInput.value.trim();
  if (!slug) {
    alert("Please provide a Kaggle dataset slug.");
    return;
  }

  const statusEl = document.getElementById("kaggleStatusMsg");
  statusEl.innerText = `Connecting to Kaggle API for '${slug}'...`;

  try {
    const res = await fetch("/api/kaggle-download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dataset_slug: slug })
    });
    const data = await res.json();
    if (data.status !== "success") {
      throw new Error(data.message);
    }
    statusEl.innerHTML = `<span style="color:#34d399;">✓ ${data.message}</span>`;
    await initDashboard();
  } catch (error) {
    statusEl.innerHTML = `<span style="color:#f43f5e;">✗ ${error.message}</span>`;
  }
}

function showLoading(show) {
  const loader = document.getElementById("globalLoader");
  if (loader) loader.style.display = show ? "block" : "none";
}

function showNotification(msg, type = "info") {
  alert(msg);
}
