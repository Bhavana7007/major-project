"""
Dataset Loader Module
Integrates Kaggle API, loads local CSVs, inspects dataset schema,
validates hydrogen production targets, and enforces strict scientific data standards.
"""
import os
import json
import logging
from pathlib import Path
from typing import Dict, Any, Tuple, Optional
import pandas as pd
import numpy as np

import config

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


class DatasetValidationError(Exception):
    """Raised when dataset does not satisfy experimental hydrogen production requirements."""
    pass


class DatasetLoader:
    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = Path(data_dir) if data_dir else config.DATA_DIR
        self.current_dataset_path = None
        self.raw_df = None
        self.cleaned_df = None
        self.target_column = None
        self.target_unit = config.DEFAULT_TARGET_UNIT
        self.catalyst_col = None
        self.metadata = {}

    def check_kaggle_auth(self) -> Dict[str, Any]:
        """Check if Kaggle API credentials are functional."""
        creds_file = config.KAGGLE_CREDENTIALS_FILE
        has_file = creds_file.exists()
        has_env = bool(os.environ.get("KAGGLE_USERNAME") and os.environ.get("KAGGLE_KEY"))
        
        status = {
            "authenticated": has_file or has_env,
            "credentials_file": str(creds_file),
            "credentials_file_exists": has_file,
            "env_vars_present": has_env,
            "message": "Kaggle API credentials detected." if (has_file or has_env) else 
                       "Kaggle API key (kaggle.json) not found. Local CSV datasets are ready to use, or you can provide credentials in config/UI."
        }
        return status

    def download_kaggle_dataset(self, dataset_slug: str) -> Tuple[bool, str, Optional[Path]]:
        """
        Download a dataset from Kaggle using the official Kaggle API.
        If credentials are not found, reports limitation clearly without pretending.
        """
        auth_status = self.check_kaggle_auth()
        if not auth_status["authenticated"]:
            msg = (
                f"Kaggle authentication is required to download '{dataset_slug}'. "
                f"Please place your 'kaggle.json' API token in '{config.KAGGLE_CONFIG_DIR}' "
                f"or set KAGGLE_USERNAME and KAGGLE_KEY environment variables."
            )
            logger.warning(msg)
            return False, msg, None

        try:
            from kaggle.api.kaggle_api_extended import KaggleApi
            api = KaggleApi()
            api.authenticate()
            
            target_dir = self.data_dir / "kaggle_downloads" / dataset_slug.replace("/", "_")
            target_dir.mkdir(parents=True, exist_ok=True)
            
            logger.info(f"Downloading Kaggle dataset '{dataset_slug}' into {target_dir}...")
            api.dataset_download_files(dataset_slug, path=str(target_dir), unzip=True)
            
            # Find CSV files in downloaded directory
            csv_files = list(target_dir.glob("*.csv"))
            if not csv_files:
                return False, f"No CSV dataset found in Kaggle download for '{dataset_slug}'.", None
            
            logger.info(f"Successfully downloaded {len(csv_files)} CSV files from Kaggle.")
            return True, f"Successfully downloaded Kaggle dataset: {csv_files[0].name}", csv_files[0]

        except Exception as e:
            err_msg = f"Failed to download Kaggle dataset '{dataset_slug}': {str(e)}"
            logger.error(err_msg)
            return False, err_msg, None

    def inspect_and_validate_columns(self, df: pd.DataFrame) -> Tuple[str, str, str]:
        """
        Inspect dataset columns.
        Validate that target represents actual measured hydrogen production rate or yield,
        and strictly reject non-production electrochemical metrics (e.g. overpotential, current density).
        """
        cols_lower = {col: col.strip().lower() for col in df.columns}
        
        # 1. Check for disallowed target patterns (e.g., overpotential treated as production)
        disallowed_present = []
        for orig_col, lower_col in cols_lower.items():
            for dis in config.DISALLOWED_TARGET_PATTERNS:
                if dis in lower_col:
                    disallowed_present.append(orig_col)
                    
        # 2. Check for legitimate hydrogen production target
        target_col = None
        for orig_col, lower_col in cols_lower.items():
            for acc in config.ACCEPTED_TARGET_PATTERNS:
                if acc in lower_col or lower_col.startswith("h2_") or "hydrogen_production" in lower_col or "h2_rate" in lower_col:
                    target_col = orig_col
                    break
            if target_col:
                break

        # If no valid H2 production target is found, or if only overpotential/current density is present
        if not target_col:
            if disallowed_present:
                err_msg = (
                    f"DATASET VALIDATION FAILED: The provided dataset only contains electrochemical metric columns "
                    f"({', '.join(disallowed_present)}) such as overpotential or current density. "
                    f"Per scientific requirements, overpotential and current density MUST NOT be treated as "
                    f"hydrogen-production percentage or rate. Actual experimental hydrogen production measurements "
                    f"(e.g., mmol/g/h or hydrogen yield) are required."
                )
            else:
                err_msg = (
                    f"DATASET VALIDATION FAILED: No measured hydrogen-production target column identified. "
                    f"Columns found: {list(df.columns)}. Target must be an actual measured H2 production rate "
                    f"or yield (e.g. 'h2_production_rate_mmol_g_h', 'hydrogen_production_rate')."
                )
            logger.error(err_msg)
            raise DatasetValidationError(err_msg)

        # 3. Detect Unit
        detected_unit = config.DEFAULT_TARGET_UNIT
        if "target_unit" in cols_lower.values():
            for orig, low in cols_lower.items():
                if low == "target_unit":
                    detected_unit = str(df[orig].dropna().iloc[0])
                    break
        elif "mmol" in target_col.lower() or "mmol/g/h" in target_col.lower():
            detected_unit = "mmol/g/h"
        elif "umol" in target_col.lower() or "μmol" in target_col.lower():
            detected_unit = "μmol/g/h"
        elif "yield" in target_col.lower():
            detected_unit = "mmol/g"

        # 4. Detect Catalyst Identity Column
        catalyst_col = None
        for orig_col, lower_col in cols_lower.items():
            if lower_col in ["catalyst_name", "catalyst", "catalyst_composition", "composition", "sample_name"]:
                catalyst_col = orig_col
                break
        
        if not catalyst_col:
            # Fallback: find first object or string column
            obj_cols = df.select_dtypes(include=["object"]).columns
            if len(obj_cols) > 0:
                catalyst_col = obj_cols[0]
            else:
                raise DatasetValidationError("Could not identify catalyst identity / name column in dataset.")

        logger.info(f"Target column validated: '{target_col}' (Unit: '{detected_unit}')")
        logger.info(f"Catalyst column identified: '{catalyst_col}'")
        return target_col, detected_unit, catalyst_col

    def clean_dataset(self, df: pd.DataFrame, target_col: str, catalyst_col: str) -> pd.DataFrame:
        """
        Clean and preprocess raw dataset:
        - Handle duplicate records
        - Handle missing values without synthetic fabrication
        - Enforce non-negative physical values
        """
        initial_len = len(df)
        
        # 1. Remove duplicate records
        df_cleaned = df.drop_duplicates().copy()
        duplicates_removed = initial_len - len(df_cleaned)
        if duplicates_removed > 0:
            logger.info(f"Removed {duplicates_removed} duplicate experimental records.")
            
        # 2. Check for missing values in target column (must not be fabricated)
        target_nulls = df_cleaned[target_col].isnull().sum()
        if target_nulls > 0:
            logger.warning(f"Dropping {target_nulls} records with missing target '{target_col}'.")
            df_cleaned = df_cleaned.dropna(subset=[target_col])

        # 3. Handle missing values in feature columns using robust empirical median/mode
        num_cols = df_cleaned.select_dtypes(include=[np.number]).columns
        for col in num_cols:
            if df_cleaned[col].isnull().sum() > 0:
                median_val = df_cleaned[col].median()
                df_cleaned[col] = df_cleaned[col].fillna(median_val)
                logger.info(f"Imputed missing values in numerical column '{col}' with median: {median_val}")

        cat_cols = df_cleaned.select_dtypes(include=["object"]).columns
        for col in cat_cols:
            if df_cleaned[col].isnull().sum() > 0:
                mode_val = df_cleaned[col].mode()[0] if not df_cleaned[col].mode().empty else "Unknown"
                df_cleaned[col] = df_cleaned[col].fillna(mode_val)
                logger.info(f"Imputed missing values in categorical column '{col}' with mode: {mode_val}")

        # 4. Standardize text whitespace in catalyst and support names
        df_cleaned[catalyst_col] = df_cleaned[catalyst_col].astype(str).str.strip()
        if "support_material" in df_cleaned.columns:
            df_cleaned["support_material"] = df_cleaned["support_material"].astype(str).str.strip()

        logger.info(f"Dataset cleaning completed. Total usable experimental records: {len(df_cleaned)}")
        return df_cleaned

    def load_dataset(self, filepath: Optional[Path] = None) -> pd.DataFrame:
        """
        Full workflow: load CSV, validate target, inspect columns, clean data.
        """
        path = Path(filepath) if filepath else config.DEFAULT_DATASET_PATH
        if not path.exists():
            raise FileNotFoundError(f"Dataset file does not exist at: {path}")

        logger.info(f"Loading experimental catalyst dataset from: {path}")
        raw_df = pd.read_csv(path)
        self.raw_df = raw_df
        self.current_dataset_path = path

        # Validation & column detection
        target_col, detected_unit, catalyst_col = self.inspect_and_validate_columns(raw_df)
        self.target_column = target_col
        self.target_unit = detected_unit
        self.catalyst_col = catalyst_col

        # Data cleaning
        cleaned_df = self.clean_dataset(raw_df, target_col, catalyst_col)
        self.cleaned_df = cleaned_df

        # Save metadata summary
        self.metadata = {
            "dataset_path": str(path),
            "total_raw_records": len(raw_df),
            "total_cleaned_records": len(cleaned_df),
            "duplicates_removed": len(raw_df) - len(cleaned_df),
            "target_column": target_col,
            "target_unit": detected_unit,
            "catalyst_column": catalyst_col,
            "unique_catalysts_count": int(cleaned_df[catalyst_col].nunique()),
            "catalysts_list": sorted(cleaned_df[catalyst_col].unique().tolist()),
            "has_primary_candidate": config.PRIMARY_CANDIDATE in cleaned_df[catalyst_col].unique(),
            "columns": list(cleaned_df.columns)
        }

        return cleaned_df

    def get_summary(self) -> Dict[str, Any]:
        """Return dataset metadata summary."""
        if not self.metadata and self.cleaned_df is not None:
            return {
                "total_records": len(self.cleaned_df),
                "target_column": self.target_column,
                "target_unit": self.target_unit,
                "catalysts_count": self.cleaned_df[self.catalyst_col].nunique()
            }
        return self.metadata
