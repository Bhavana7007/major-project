"""
Preprocessing Pipeline Module
Handles feature selection, categorical one-hot encoding, feature standardization,
and train-test splitting without data leakage.
"""
import joblib
from pathlib import Path
from typing import Tuple, List, Optional
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer

import config


class CatalystDataPreprocessor:
    def __init__(self):
        self.preprocessor = None
        self.feature_columns = []
        self.numerical_cols = []
        self.categorical_cols = []
        self.feature_names_out = []
        self.target_column = None

    def separate_features_and_target(
        self, df: pd.DataFrame, target_col: str
    ) -> Tuple[pd.DataFrame, pd.Series]:
        """
        Separate features and target, strictly excluding non-feature metadata
        and target-derived columns to prevent data leakage.
        """
        self.target_column = target_col
        y = df[target_col].copy()

        # Exclude target and metadata columns (DOIs, units, references)
        non_feature_cols = [
            target_col,
            "target_unit",
            "doi_reference",
            "doi",
            "reference",
            "source",
            "id",
            "sample_id"
        ]

        feature_df = df.drop(columns=[col for col in non_feature_cols if col in df.columns]).copy()
        
        self.feature_columns = list(feature_df.columns)
        self.numerical_cols = list(feature_df.select_dtypes(include=[np.number]).columns)
        self.categorical_cols = list(feature_df.select_dtypes(include=["object"]).columns)

        return feature_df, y

    def build_transformer(self) -> ColumnTransformer:
        """
        Build scikit-learn ColumnTransformer with OneHotEncoder for categoricals
        and StandardScaler for numerical features.
        """
        transformers = []

        if self.numerical_cols:
            transformers.append(
                ("num", StandardScaler(), self.numerical_cols)
            )

        if self.categorical_cols:
            transformers.append(
                ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), self.categorical_cols)
            )

        self.preprocessor = ColumnTransformer(
            transformers=transformers,
            remainder="drop"
        )
        return self.preprocessor

    def fit_transform_split(
        self,
        df: pd.DataFrame,
        target_col: str,
        test_size: float = 0.20,
        random_state: int = 42
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, pd.DataFrame, pd.DataFrame]:
        """
        Splits data first to prevent data leakage, then fits transformer ONLY on training set.
        """
        X, y = self.separate_features_and_target(df, target_col)

        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state
        )

        # Build and fit transformer on X_train ONLY
        self.build_transformer()
        X_train_trans = self.preprocessor.fit_transform(X_train)
        X_test_trans = self.preprocessor.transform(X_test)

        # Extract output feature names for feature importance analysis
        self._extract_feature_names()

        return X_train_trans, X_test_trans, y_train.values, y_test.values, X_train, X_test

    def _extract_feature_names(self):
        """Extract legible feature names after one-hot encoding."""
        feature_names = []
        if hasattr(self.preprocessor, "get_feature_names_out"):
            try:
                raw_names = self.preprocessor.get_feature_names_out()
                feature_names = [name.replace("num__", "").replace("cat__", "") for name in raw_names]
            except Exception:
                feature_names = self.numerical_cols + [f"{col}_cat" for col in self.categorical_cols]
        else:
            feature_names = self.numerical_cols + [f"{col}_cat" for col in self.categorical_cols]

        self.feature_names_out = feature_names

    def transform_single_or_df(self, df_input: pd.DataFrame) -> np.ndarray:
        """Transform new inference samples."""
        if self.preprocessor is None:
            raise ValueError("Preprocessor has not been fitted or loaded.")
            
        # Ensure all required feature columns exist, imputing default if missing
        df_copy = df_input.copy()
        for col in self.feature_columns:
            if col not in df_copy.columns:
                if col in self.numerical_cols:
                    df_copy[col] = 0.0
                else:
                    df_copy[col] = "Unknown"

        X_subset = df_copy[self.feature_columns]
        return self.preprocessor.transform(X_subset)

    def save(self, filepath: Optional[Path] = None):
        """Save fitted preprocessor."""
        path = Path(filepath) if filepath else config.PREPROCESSOR_PATH
        state = {
            "preprocessor": self.preprocessor,
            "feature_columns": self.feature_columns,
            "numerical_cols": self.numerical_cols,
            "categorical_cols": self.categorical_cols,
            "feature_names_out": self.feature_names_out,
            "target_column": self.target_column
        }
        joblib.dump(state, path)

    @classmethod
    def load(cls, filepath: Optional[Path] = None) -> "CatalystDataPreprocessor":
        """Load fitted preprocessor."""
        path = Path(filepath) if filepath else config.PREPROCESSOR_PATH
        if not path.exists():
            raise FileNotFoundError(f"Preprocessor file not found at: {path}")
        state = joblib.load(path)
        inst = cls()
        inst.preprocessor = state["preprocessor"]
        inst.feature_columns = state["feature_columns"]
        inst.numerical_cols = state["numerical_cols"]
        inst.categorical_cols = state["categorical_cols"]
        inst.feature_names_out = state["feature_names_out"]
        inst.target_column = state["target_column"]
        return inst
