"""
Verification test script for all Flask REST APIs and HTML routes.
"""
import json
from app import app

client = app.test_client()

print("=== 1. Testing GET /api/status ===")
res = client.get("/api/status")
assert res.status_code == 200, f"Expected 200, got {res.status_code}"
data = res.get_json()
print("Project:", data.get("project_title"))
print("Active Model:", data.get("model_performance", {}).get("active_model"))
print("R2 Score:", data.get("model_performance", {}).get("r2_score"))
print("MAE:", data.get("model_performance", {}).get("mae"), data.get("dataset", {}).get("target_unit"))
print("Kaggle Auth Status:", data.get("dataset", {}).get("kaggle_integration", {}).get("authenticated"))

print("\n=== 2. Testing GET /api/best-catalyst ===")
res = client.get("/api/best-catalyst")
assert res.status_code == 200
best = res.get_json().get("best_catalyst")
print("Winner:", best.get("catalyst_name"))
print("Predicted Rate:", best.get("predicted_h2_rate"), best.get("target_unit"))
print("Rank:", best.get("ranking"), "of", best.get("total_catalysts"))
print("Advantage vs Runner-up:", best.get("pct_difference_vs_runner_up"), "%")

print("\n=== 3. Testing GET /api/catalysts ===")
res = client.get("/api/catalysts")
assert res.status_code == 200
cats = res.get_json()
print("Total Catalysts Count:", cats.get("count"))
for c in cats.get("catalysts", [])[:5]:
    print(f" - Rank #{c['ranking']}: {c['catalyst_name']} -> {c['predicted_h2_rate']} {c['target_unit']}")

print("\n=== 4. Testing GET /api/catalyst/Pt-Ru-Ni/C ===")
res = client.get("/api/catalyst/Pt-Ru-Ni/C")
assert res.status_code == 200
details = res.get_json().get("catalyst")
print("Name:", details.get("catalyst_name"))
print("Ranking:", details.get("ranking"))
print("Predicted Rate:", details.get("predicted_h2_rate"), details.get("target_unit"))
print("Measured Mean:", details.get("measured_h2_rate_mean"), details.get("target_unit"))
print("Experimental Records Count:", details.get("record_count"))
print("Candidate Analysis Note:", details.get("candidate_analysis", {}).get("status_note"))

print("\n=== 5. Testing GET /api/compare ===")
res = client.get("/api/compare")
assert res.status_code == 200
comp = res.get_json().get("data")
print("Catalysts compared count:", len(comp.get("labels", [])))
print("Best highlighted:", comp.get("best_catalyst"))
print("Primary candidate highlighted:", comp.get("primary_candidate"))

print("\n=== 6. Testing POST /api/predict-custom ===")
payload = {
    "catalyst_name": "Simulated Pt-Ru-Ni/C Variant",
    "pt_loading_wt_pct": 2.5,
    "ru_loading_wt_pct": 2.0,
    "ni_loading_wt_pct": 2.0,
    "support_material": "Vulcan Carbon XC-72",
    "reaction_temperature_c": 65.0,
    "bet_surface_area_m2_g": 550.0,
    "avg_particle_size_nm": 2.6
}
res = client.post("/api/predict-custom", data=json.dumps(payload), content_type="application/json")
assert res.status_code == 200
pred = res.get_json().get("prediction")
print("Custom Formulation Predicted Rate:", pred.get("predicted_h2_rate"), pred.get("target_unit"))

print("\n=== 7. Testing Frontend Route GET / ===")
res = client.get("/")
assert res.status_code == 200
print("HTML Response Length:", len(res.data), "bytes")

print("\n=== 8. Testing Standalone Detail Route GET /catalyst/Pt-Ru-Ni/C ===")
res = client.get("/catalyst/Pt-Ru-Ni/C")
assert res.status_code == 200
print("Detail HTML Response Length:", len(res.data), "bytes")

print("\n==============================================")
print(">>> ALL UNIT & INTEGRATION TESTS PASSED 100%! <<<")
print("==============================================")
