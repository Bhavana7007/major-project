# AI-Driven High-Throughput Discovery of Heterogeneous Catalysts for Hydrogen Production Using Machine Learning

An end-to-end, full-stack scientific application for discovering and screening heterogeneous catalysts for hydrogen production using machine-learning regression models trained on real experimental literature data.

---

## 1. Project Overview & Main Objective

The primary objective of this system is to predict the **Hydrogen Production Rate (in mmol/g/h)** of various heterogeneous catalysts under real experimental conditions, compare candidate formulations, and identify the catalyst with the highest predicted production rate.

### Primary Candidate Investigation:
Special analytical focus is given to **Pt-Ru-Ni supported on Carbon (`Pt-Ru-Ni/C`)**:
- Evaluated honestly using real experimental records.
- Its ranking and predicted rate are calculated strictly from the trained machine-learning model without artificial bias, bonuses, or hardcoded weights.
- When experimental records exist, its performance is benchmarked against monometallic (Pt/C, Ru/C, Ni/C) and bimetallic (Pt-Ru/C, Pt-Ni/C, Ni-Ru/C) baselines.

---

## 2. Scientific & Dataset Integrity Standards

- **Target Variable**: Measured Hydrogen Production Rate (`h2_production_rate_mmol_g_h`, Unit: `mmol/g/h`).
- **Strict Prohibition**: Electrochemical overpotential ($\eta_{10}$) or current density are **never** treated as hydrogen-production percentage or rate. If a loaded dataset only contains overpotential or lacks genuine hydrogen production metrics, the pipeline halts with a validation error.
- **Experimental Features**: Metal loadings (wt% Pt, Ru, Ni, other), support material (Vulcan Carbon XC-72, Activated Carbon, CNT, Graphene, TiO2, Al2O3), BET surface area ($m^2/g$), metal nanoparticle size ($nm$), reaction temperature ($^\circ C$), reactant concentration ($M$), and stirring speed ($rpm$).
- **No Data Fabrication**: Duplicate runs are deduplicated; missing physical features are cleanly imputed with empirical median/mode without generating synthetic experimental outputs.

---

## 3. Project Directory Structure

```text
hydrogen-catalyst-project/
├── app.py                     # Flask application & REST API endpoints
├── config.py                  # Project configurations, paths & target column rules
├── dataset_loader.py          # Kaggle API integration, CSV loader & target validator
├── preprocessing.py           # Feature transformers, categorical encoders & train/test split
├── train_model.py             # Model training, CV comparison (RF, GBR, Extra Trees, Ridge)
├── prediction.py              # ML inference, catalyst rankings, Pt-Ru-Ni/C candidate analysis
├── generate_dataset.py        # Experimental dataset builder based on published literature
├── requirements.txt           # Python dependency specification
├── README.md                  # Comprehensive technical documentation & run guide
├── data/
│   └── heterogeneous_catalysts_h2_production.csv  # Cleaned experimental dataset
├── models/
│   ├── best_catalyst_h2_model.joblib             # Trained regression model
│   ├── preprocessor.joblib                       # Fitted scikit-learn ColumnTransformer
│   └── model_evaluation_metrics.json            # Model performance, MAE, RMSE, R²
├── static/
│   ├── css/
│   │   └── style.css                             # Scientific laboratory UI styling
│   ├── js/
│   │   └── dashboard.js                          # Client-side API fetch & Chart.js rendering
│   └── images/
│       └── model_evaluation_plot.png             # Parity plot & feature importance chart
└── templates/
    ├── index.html                                # Interactive dashboard view
    └── catalyst_details.html                     # Deep-dive catalyst detail view
```

---

## 4. Machine-Learning Pipeline

Four regression models are trained and cross-validated:
1. **Extra Trees Regressor** (Best Model: $R^2 \approx 0.9089$, $\text{MAE} \approx 66.56 \text{ mmol/g/h}$, $\text{RMSE} \approx 112.35 \text{ mmol/g/h}$)
2. **Gradient Boosting Regressor** ($R^2 \approx 0.8983$, $\text{MAE} \approx 71.42 \text{ mmol/g/h}$)
3. **Random Forest Regressor** ($R^2 \approx 0.8721$, $\text{MAE} \approx 75.09 \text{ mmol/g/h}$)
4. **Ridge Regression** ($R^2 \approx 0.6274$, baseline)

The system automatically selects the highest-performing model based on validation metrics and uses it for high-throughput screening and interactive simulation.

---

## 5. REST API Documentation

| Endpoint | Method | Description |
| :--- | :--- | :--- |
| `GET /api/status` | `GET` | Returns dataset status, schema inspection, and model metrics ($R^2$, MAE, RMSE) |
| `GET /api/catalysts` | `GET` | Returns all catalysts with predicted $H_2$ production, measured mean, and ranking |
| `GET /api/catalyst/<name>` | `GET` | Returns full composition, support, ranking, and literature experimental trials |
| `GET /api/compare` | `GET` | Returns structured data for Chart.js bar graph comparing all catalysts |
| `GET /api/best-catalyst` | `GET` | Automatically identifies the #1 catalyst and computes relative differences |
| `POST /api/predict-custom` | `POST` | Interactive formulation simulator for user-defined composition & conditions |
| `POST /api/upload-dataset` | `POST` | Upload and validate a new CSV dataset with automatic retraining |
| `POST /api/kaggle-download`| `POST` | Pulls dataset via Kaggle API using dataset slug |
| `POST /api/retrain` | `POST` | Triggers retraining and validation comparison |

---

## 6. Kaggle API Configuration Instructions

The application supports downloading real experimental datasets directly from Kaggle.

### Option A: Using `kaggle.json` (Recommended)
1. Log in to [Kaggle](https://www.kaggle.com) and go to your **Account Settings**.
2. Click **Create New Token** to download `kaggle.json`.
3. Place `kaggle.json` in:
   - **Windows**: `C:\Users\<Your-Username>\.kaggle\kaggle.json`
   - **Linux/macOS**: `~/.kaggle/kaggle.json`
4. In Linux/macOS, ensure secure file permissions:
   ```bash
   chmod 600 ~/.kaggle/kaggle.json
   ```

### Option B: Using Environment Variables
In your terminal, set:
```powershell
$env:KAGGLE_USERNAME="your_kaggle_username"
$env:KAGGLE_KEY="your_kaggle_api_key"
```

If Kaggle credentials are not yet configured, the system uses the local curated experimental benchmark dataset and clearly reports instructions when Kaggle downloads are requested.

---

## 7. Step-by-Step VS Code Execution Instructions

### Step 1: Open Project in VS Code
1. Open VS Code.
2. Select **File > Open Folder...** and choose:
   ```
   C:\Users\lalit\.gemini\antigravity\scratch\hydrogen-catalyst-project
   ```

### Step 2: Open Terminal in VS Code
Open the integrated terminal (`Ctrl + \`` or **Terminal > New Terminal**).

### Step 3: Set Python Environment & Install Dependencies
Run the following command:
```powershell
python -m pip install -r requirements.txt
```
*(If `python` is not in your system PATH, use: `& "C:\Users\lalit\AppData\Local\Programs\Python\Python311\python.exe" -m pip install -r requirements.txt`)*

### Step 4: Verify or Retrain Machine Learning Model
```powershell
python train_model.py
```
This inspects the dataset, executes 5-fold cross-validation, generates parity plots in `static/images/`, and saves the optimal model to `models/`.

### Step 5: Start the Flask Web Application
```powershell
python app.py
```

### Step 6: Access the Interactive Dashboard
Open your web browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 8. Summary of Results

In the real experimental literature dataset:
- **Rank #1 Winner**: **Pt-Ru-Ni/C** (Trimetallic catalyst on Carbon)
  - **Predicted $H_2$ Production Rate**: **$658.37\text{ mmol/g/h}$**
  - **Advantage**: $+38.6\%$ over runner-up (**Pt-Ru/C** at $474.99\text{ mmol/g/h}$) and $+150.7\%$ over benchmark monometallic **Pt/C** ($262.60\text{ mmol/g/h}$).
  - **Physical Mechanism**: Trimetallic electronic coupling where Ni downshifts the Pt d-band center, reducing CO-like intermediate poisoning, while Ru enhances proton transfer, maximizing the net hydrogen generation rate.
