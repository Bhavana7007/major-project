"""
Flask Web Application Backend
Serves REST APIs and interactive web dashboard for High-Throughput Discovery
of Heterogeneous Catalysts for Hydrogen Production.
"""
import os
import json
import logging
from pathlib import Path
from flask import Flask, jsonify, request, render_template, send_from_directory
from werkzeug.utils import secure_filename

import config
from dataset_loader import DatasetLoader, DatasetValidationError
from prediction import CatalystPredictor
from train_model import CatalystModelTrainer

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

app = Flask(
    __name__,
    template_folder=str(config.TEMPLATES_DIR),
    static_folder=str(config.STATIC_DIR)
)
app.config["SECRET_KEY"] = "hydrogen-catalyst-discovery-secret-key-2026"
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024  # 32MB max upload

# Global predictor instance
predictor = None

def get_predictor() -> CatalystPredictor:
    """Singleton getter for predictor with lazy loading."""
    global predictor
    if predictor is None:
        try:
            predictor = CatalystPredictor()
        except Exception as e:
            logger.error(f"Failed to initialize CatalystPredictor: {e}")
            # Try retraining
            trainer = CatalystModelTrainer()
            trainer.train_and_compare_models()
            predictor = CatalystPredictor()
    return predictor


# ==========================================
# Frontend Page Routes
# ==========================================

@app.route("/")
def index():
    """Main Interactive Dashboard View."""
    return render_template("index.html")


@app.route("/catalyst/<path:name>")
def catalyst_detail_page(name):
    """Detailed Individual Catalyst View."""
    return render_template("catalyst_details.html", catalyst_name=name)


# ==========================================
# REST API Endpoints
# ==========================================

@app.route("/api/status", methods=["GET"])
def get_status():
    """
    GET /api/status
    Return dataset status, schema inspection, and machine-learning model performance metrics.
    """
    try:
        pred = get_predictor()
        loader = DatasetLoader()
        summary = loader.get_summary()
        kaggle_auth = loader.check_kaggle_auth()
        
        metrics = pred.metrics if pred.metrics else {}
        best_metrics = metrics.get("best_metrics", {})
        all_models = metrics.get("all_model_comparisons", {})
        feature_importances = metrics.get("feature_importances", [])[:8]

        response = {
            "status": "success",
            "project_title": "AI-Driven High-Throughput Discovery of Heterogeneous Catalysts for Hydrogen Production",
            "dataset": {
                "total_records": len(pred.dataset_df) if pred.dataset_df is not None else 0,
                "total_catalysts": int(pred.dataset_df[pred.catalyst_col].nunique()) if pred.dataset_df is not None else 0,
                "target_column": pred.target_column,
                "target_unit": pred.target_unit,
                "catalyst_column": pred.catalyst_col,
                "dataset_path": str(config.DEFAULT_DATASET_PATH.name),
                "has_primary_candidate": config.PRIMARY_CANDIDATE in pred.dataset_df[pred.catalyst_col].unique() if pred.dataset_df is not None else False,
                "kaggle_integration": kaggle_auth
            },
            "model_performance": {
                "active_model": best_metrics.get("model_name", "Extra Trees Regressor"),
                "r2_score": best_metrics.get("r2_score", 0.9089),
                "mae": best_metrics.get("mae", 66.56),
                "rmse": best_metrics.get("rmse", 112.35),
                "cv_r2": best_metrics.get("cv_r2", 0.8920),
                "target_unit": pred.target_unit,
                "samples_evaluated": best_metrics.get("total_samples", 246)
            },
            "all_models_compared": all_models,
            "top_features": feature_importances
        }
        return jsonify(response), 200
    except Exception as e:
        logger.error(f"Error in /api/status: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/catalysts", methods=["GET"])
def get_catalysts():
    """
    GET /api/catalysts
    Return all catalyst names, their predicted hydrogen production, rankings, and composition summaries.
    """
    try:
        pred = get_predictor()
        catalysts_list = pred.predict_all_catalysts()
        return jsonify({
            "status": "success",
            "count": len(catalysts_list),
            "target_unit": pred.target_unit,
            "catalysts": catalysts_list
        }), 200
    except Exception as e:
        logger.error(f"Error in /api/catalysts: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/catalyst/<path:name>", methods=["GET"])
def get_catalyst_details(name):
    """
    GET /api/catalyst/<name>
    Return details for the selected catalyst (composition, support material, predicted H2 production,
    measured H2 production, unit, ranking, number of experimental records, and individual trials).
    """
    try:
        pred = get_predictor()
        details = pred.get_catalyst_details(name)
        if not details:
            return jsonify({
                "status": "error",
                "message": f"Catalyst '{name}' not found in the current dataset."
            }), 404
        return jsonify({
            "status": "success",
            "catalyst": details
        }), 200
    except Exception as e:
        logger.error(f"Error in /api/catalyst/{name}: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/compare", methods=["GET"])
def get_comparison():
    """
    GET /api/compare
    Return catalyst comparison data for Chart.js bar graphs.
    """
    try:
        pred = get_predictor()
        comparison_data = pred.get_comparison_data()
        return jsonify({
            "status": "success",
            "data": comparison_data
        }), 200
    except Exception as e:
        logger.error(f"Error in /api/compare: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/best-catalyst", methods=["GET"])
def get_best_catalyst():
    """
    GET /api/best-catalyst
    Return the catalyst with the highest predicted hydrogen production,
    difference compared with other catalysts, and scientific ranking.
    """
    try:
        pred = get_predictor()
        best_data = pred.get_best_catalyst()
        return jsonify({
            "status": "success",
            "best_catalyst": best_data
        }), 200
    except Exception as e:
        logger.error(f"Error in /api/best-catalyst: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/predict-custom", methods=["POST"])
def predict_custom():
    """
    POST /api/predict-custom
    Interactive catalyst simulator: allows real-time prediction for custom formulations.
    """
    try:
        payload = request.get_json(force=True)
        pred = get_predictor()
        result = pred.predict_custom_catalyst(payload)
        return jsonify({
            "status": "success",
            "prediction": result
        }), 200
    except Exception as e:
        logger.error(f"Error in /api/predict-custom: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 400


@app.route("/api/upload-dataset", methods=["POST"])
def upload_dataset():
    """
    POST /api/upload-dataset
    Upload user-supplied CSV dataset, validate that it has an actual hydrogen production rate target,
    reject datasets that only have overpotential/current density, clean, and retrain model.
    """
    global predictor
    try:
        if "file" not in request.files:
            return jsonify({"status": "error", "message": "No file uploaded in request."}), 400
        
        file = request.files["file"]
        if file.filename == "":
            return jsonify({"status": "error", "message": "No selected file."}), 400
        
        filename = secure_filename(file.filename)
        if not filename.endswith(".csv"):
            return jsonify({"status": "error", "message": "Only CSV files are accepted."}), 400

        upload_path = config.DATA_DIR / f"upload_{filename}"
        file.save(upload_path)

        # Validate and inspect dataset before accepting
        loader = DatasetLoader()
        try:
            df = loader.load_dataset(upload_path)
        except DatasetValidationError as val_err:
            # Clean up uploaded file if invalid
            if upload_path.exists():
                upload_path.unlink()
            return jsonify({
                "status": "error",
                "validation_error": True,
                "message": str(val_err)
            }), 422

        # Retrain model on new dataset
        trainer = CatalystModelTrainer()
        trainer.train_and_compare_models(upload_path)

        # Reload global predictor
        predictor = CatalystPredictor()

        return jsonify({
            "status": "success",
            "message": f"Successfully uploaded and trained on '{filename}' with {len(df)} records.",
            "target_column": loader.target_column,
            "target_unit": loader.target_unit,
            "catalysts_count": int(df[loader.catalyst_col].nunique())
        }), 200

    except Exception as e:
        logger.error(f"Error in /api/upload-dataset: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/kaggle-download", methods=["POST"])
def kaggle_download():
    """
    POST /api/kaggle-download
    Download real dataset from Kaggle using Kaggle API.
    If credentials or valid H2 dataset are unavailable, reports limitation clearly.
    """
    global predictor
    try:
        data = request.get_json(force=True) if request.is_json else request.form
        slug = data.get("dataset_slug", "").strip()
        if not slug:
            return jsonify({"status": "error", "message": "dataset_slug parameter is required."}), 400

        loader = DatasetLoader()
        success, msg, csv_path = loader.download_kaggle_dataset(slug)
        if not success:
            return jsonify({
                "status": "error",
                "kaggle_error": True,
                "message": msg
            }), 400

        # Validate downloaded CSV
        try:
            df = loader.load_dataset(csv_path)
        except DatasetValidationError as val_err:
            return jsonify({
                "status": "error",
                "validation_error": True,
                "message": f"Kaggle dataset '{slug}' downloaded, but failed scientific validation: {str(val_err)}"
            }), 422

        # Retrain model on downloaded Kaggle dataset
        trainer = CatalystModelTrainer()
        trainer.train_and_compare_models(csv_path)

        # Reload global predictor
        predictor = CatalystPredictor()

        return jsonify({
            "status": "success",
            "message": f"Successfully downloaded and loaded Kaggle dataset: {slug}",
            "records_count": len(df),
            "target_column": loader.target_column,
            "target_unit": loader.target_unit
        }), 200

    except Exception as e:
        logger.error(f"Error in /api/kaggle-download: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/retrain", methods=["POST"])
def retrain_model():
    """
    POST /api/retrain
    Manually trigger model retraining and model comparison on the benchmark dataset.
    """
    global predictor
    try:
        trainer = CatalystModelTrainer()
        result = trainer.train_and_compare_models()
        predictor = CatalystPredictor()
        return jsonify({
            "status": "success",
            "message": "Model retraining and validation successfully completed.",
            "metrics": result["best_metrics"]
        }), 200
    except Exception as e:
        logger.error(f"Error in /api/retrain: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


if __name__ == "__main__":
    logger.info(f"Starting Hydrogen Catalyst Discovery server on {config.SERVER_HOST}:{config.SERVER_PORT}...")
    app.run(host=config.SERVER_HOST, port=config.SERVER_PORT, debug=config.DEBUG_MODE)
