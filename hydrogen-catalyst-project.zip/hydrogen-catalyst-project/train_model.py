"""
Model Training & Evaluation Module
Trains, cross-validates, and compares regression models (Random Forest, Gradient Boosting, Extra Trees, Ridge)
for Hydrogen Production Rate prediction. Evaluates MAE, RMSE, R2, and feature importances.
"""
import os
import json
import logging
from pathlib import Path
from typing import Dict, Any, Tuple
import joblib
import pandas as pd
import numpy as np

# Set Matplotlib backend and temporary config directory to prevent permission warnings
os.environ["MPLCONFIGDIR"] = os.environ.get("TEMP", "C:/Temp")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score

import config
from dataset_loader import DatasetLoader
from preprocessing import CatalystDataPreprocessor

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


class CatalystModelTrainer:
    def __init__(self):
        self.preprocessor = CatalystDataPreprocessor()
        self.models_dict = {
            "Random Forest Regressor": RandomForestRegressor(
                n_estimators=120, max_depth=12, min_samples_split=3, random_state=42
            ),
            "Gradient Boosting Regressor": GradientBoostingRegressor(
                n_estimators=120, learning_rate=0.08, max_depth=5, random_state=42
            ),
            "Extra Trees Regressor": ExtraTreesRegressor(
                n_estimators=120, max_depth=12, min_samples_split=3, random_state=42
            ),
            "Ridge Regression (Linear Baseline)": Ridge(alpha=1.0)
        }
        self.best_model_name = None
        self.best_model = None
        self.best_metrics = {}
        self.all_model_results = {}
        self.feature_importances = []
        self.target_unit = config.DEFAULT_TARGET_UNIT

    def train_and_compare_models(
        self, dataset_path: Path = config.DEFAULT_DATASET_PATH
    ) -> Dict[str, Any]:
        """
        Load dataset, preprocess, train and compare models, select best model, and save artifacts.
        """
        loader = DatasetLoader()
        df = loader.load_dataset(dataset_path)
        target_col = loader.target_column
        self.target_unit = loader.target_unit

        logger.info(f"Training models for target: '{target_col}' ({self.target_unit}) on {len(df)} records")

        # Split and preprocess
        (
            X_train,
            X_test,
            y_train,
            y_test,
            df_train_raw,
            df_test_raw
        ) = self.preprocessor.fit_transform_split(df, target_col, test_size=0.20, random_state=42)

        results = {}
        best_score = -float("inf")

        for name, model in self.models_dict.items():
            logger.info(f"Training and validating {name}...")
            # 5-fold cross validation on train set
            cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring="r2")
            cv_r2_mean = float(np.mean(cv_scores))

            # Train on full train set
            model.fit(X_train, y_train)

            # Predict on test set
            y_pred = model.predict(X_test)

            mae = float(mean_absolute_error(y_test, y_pred))
            rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))
            r2 = float(r2_score(y_test, y_pred))

            results[name] = {
                "cv_r2_mean": round(cv_r2_mean, 4),
                "test_r2": round(r2, 4),
                "test_mae": round(mae, 2),
                "test_rmse": round(rmse, 2),
                "model_instance": model,
                "y_pred": y_pred.tolist(),
                "y_test": y_test.tolist()
            }

            logger.info(f"{name} -> Test R2: {r2:.4f}, MAE: {mae:.2f} {self.target_unit}, RMSE: {rmse:.2f} {self.target_unit}")

            # Best model selection based on test R²
            if r2 > best_score:
                best_score = r2
                self.best_model_name = name
                self.best_model = model
                self.best_metrics = {
                    "model_name": name,
                    "r2_score": round(r2, 4),
                    "mae": round(mae, 2),
                    "rmse": round(rmse, 2),
                    "cv_r2": round(cv_r2_mean, 4),
                    "target_column": target_col,
                    "target_unit": self.target_unit,
                    "training_samples": len(X_train),
                    "testing_samples": len(X_test),
                    "total_samples": len(df)
                }

        self.all_model_results = results
        logger.info(f"Selected Best Model: '{self.best_model_name}' (Test R2: {self.best_metrics['r2_score']:.4f})")

        # Extract Feature Importances for best model
        self._calculate_feature_importances()

        # Save model and preprocessor
        self.save_artifacts()

        # Generate evaluation and parity plots
        self._generate_diagnostic_plots(
            results[self.best_model_name]["y_test"],
            results[self.best_model_name]["y_pred"]
        )

        return {
            "best_metrics": self.best_metrics,
            "all_models": {
                name: {
                    "cv_r2": res["cv_r2_mean"],
                    "test_r2": res["test_r2"],
                    "test_mae": res["test_mae"],
                    "test_rmse": res["test_rmse"]
                }
                for name, res in results.items()
            },
            "feature_importances": self.feature_importances[:10]
        }

    def _calculate_feature_importances(self):
        """Extract and rank feature importances from best model."""
        feature_names = self.preprocessor.feature_names_out
        importances = []

        if hasattr(self.best_model, "feature_importances_"):
            raw_imp = self.best_model.feature_importances_
            for name, imp in zip(feature_names, raw_imp):
                importances.append({"feature": name, "importance": round(float(imp), 4)})
        elif hasattr(self.best_model, "coef_"):
            raw_coef = np.abs(self.best_model.coef_)
            norm_coef = raw_coef / np.sum(raw_coef)
            for name, imp in zip(feature_names, norm_coef):
                importances.append({"feature": name, "importance": round(float(imp), 4)})

        # Sort descending
        importances = sorted(importances, key=lambda x: x["importance"], reverse=True)
        self.feature_importances = importances

    def _generate_diagnostic_plots(self, y_test: list, y_pred: list):
        """Generate parity plot and feature importance visual chart."""
        img_dir = config.STATIC_DIR / "images"
        img_dir.mkdir(parents=True, exist_ok=True)
        plot_path = img_dir / "model_evaluation_plot.png"

        try:
            fig, axes = plt.subplots(1, 2, figsize=(14, 5.5), dpi=120)

            # 1. Parity Plot: Actual vs Predicted H2 Production Rate
            y_test_arr = np.array(y_test)
            y_pred_arr = np.array(y_pred)
            axes[0].scatter(y_test_arr, y_pred_arr, color="#2563eb", alpha=0.75, edgecolors="k", s=45, label="Test Records")
            min_val = min(y_test_arr.min(), y_pred_arr.min()) * 0.9
            max_val = max(y_test_arr.max(), y_pred_arr.max()) * 1.05
            axes[0].plot([min_val, max_val], [min_val, max_val], "r--", linewidth=1.8, label="Ideal 1:1 Parity")
            axes[0].set_xlabel(f"Measured H2 Rate ({self.target_unit})", fontsize=11, fontweight="bold")
            axes[0].set_ylabel(f"Predicted H2 Rate ({self.target_unit})", fontsize=11, fontweight="bold")
            axes[0].set_title(
                f"Parity Plot: {self.best_model_name}\n"
                f"R² = {self.best_metrics['r2_score']} | MAE = {self.best_metrics['mae']} {self.target_unit}",
                fontsize=11
            )
            axes[0].grid(True, linestyle=":", alpha=0.6)
            axes[0].legend(loc="upper left")

            # 2. Top 8 Feature Importances
            top_features = self.feature_importances[:8]
            feat_names = [f["feature"] for f in top_features][::-1]
            feat_vals = [f["importance"] for f in top_features][::-1]
            axes[1].barh(feat_names, feat_vals, color="#059669", edgecolor="#047857", alpha=0.85)
            axes[1].set_xlabel("Relative Importance Score", fontsize=11, fontweight="bold")
            axes[1].set_title("Top Chemical & Reaction Features Driving H2 Production", fontsize=11)
            axes[1].grid(True, linestyle=":", alpha=0.6)

            plt.tight_layout()
            plt.savefig(plot_path)
            plt.close()
            logger.info(f"Model diagnostic evaluation plot saved to: {plot_path}")
        except Exception as e:
            logger.warning(f"Could not generate evaluation plot: {e}")

    def save_artifacts(self):
        """Save best model, preprocessor, and metrics JSON."""
        # Save model
        joblib.dump(self.best_model, config.TRAINED_MODEL_PATH)
        logger.info(f"Trained model saved to: {config.TRAINED_MODEL_PATH}")

        # Save preprocessor
        self.preprocessor.save(config.PREPROCESSOR_PATH)
        logger.info(f"Preprocessor saved to: {config.PREPROCESSOR_PATH}")

        # Save metrics and comparisons
        metrics_payload = {
            "best_metrics": self.best_metrics,
            "all_model_comparisons": {
                name: {
                    "cv_r2": res["cv_r2_mean"],
                    "test_r2": res["test_r2"],
                    "test_mae": res["test_mae"],
                    "test_rmse": res["test_rmse"]
                }
                for name, res in self.all_model_results.items()
            },
            "feature_importances": self.feature_importances
        }
        with open(config.METRICS_PATH, "w") as f:
            json.dump(metrics_payload, f, indent=2)
        logger.info(f"Evaluation metrics saved to: {config.METRICS_PATH}")


if __name__ == "__main__":
    trainer = CatalystModelTrainer()
    trainer.train_and_compare_models()
