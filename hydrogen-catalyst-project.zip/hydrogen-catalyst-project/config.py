import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"

# Create directories if they do not exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)

# Default Dataset & Model Files
DEFAULT_DATASET_PATH = DATA_DIR / "heterogeneous_catalysts_h2_production.csv"
TRAINED_MODEL_PATH = MODELS_DIR / "best_catalyst_h2_model.joblib"
METRICS_PATH = MODELS_DIR / "model_evaluation_metrics.json"
FEATURE_NAMES_PATH = MODELS_DIR / "feature_names.json"
PREPROCESSOR_PATH = MODELS_DIR / "preprocessor.joblib"

# Kaggle Configuration
KAGGLE_CONFIG_DIR = Path(os.environ.get("KAGGLE_CONFIG_DIR", Path.home() / ".kaggle"))
KAGGLE_CREDENTIALS_FILE = KAGGLE_CONFIG_DIR / "kaggle.json"
DEFAULT_KAGGLE_DATASET_SLUG = "catalyst-hydrogen-production-benchmarks"

# Acceptable Target Column Patterns (Actual measured hydrogen production)
ACCEPTED_TARGET_PATTERNS = [
    "h2_production_rate_mmol_g_h",
    "h2_rate_mmol_g_h",
    "hydrogen_production_rate",
    "hydrogen_yield_mmol_g_h",
    "h2_production_rate",
    "hydrogen_rate_mmol_g_h",
    "h2_evolution_rate_mmol_g_h",
    "h2_rate_umol_g_h",
    "hydrogen_yield"
]

# Prohibited Targets that are NOT hydrogen production rate
# (e.g. overpotential, current density, Tafel slope, arbitrary percentages)
DISALLOWED_TARGET_PATTERNS = [
    "overpotential",
    "eta_10",
    "current_density",
    "tafel_slope",
    "faradaic_efficiency_pct",
    "efficiency_percentage"
]

# Primary Target Unit
DEFAULT_TARGET_UNIT = "mmol/g/h"

# Primary Candidate to Evaluate
PRIMARY_CANDIDATE = "Pt-Ru-Ni/C"

# Flask Server Config
SERVER_HOST = "127.0.0.1"
SERVER_PORT = 5000
DEBUG_MODE = True
