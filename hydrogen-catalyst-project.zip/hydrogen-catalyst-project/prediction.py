"""
Prediction & Candidate Analysis Module
Generates ML model predictions for all heterogeneous catalysts, calculates rankings,
identifies the best hydrogen-producing catalyst, and performs honest candidate analysis on Pt-Ru-Ni/C.
"""
import json
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional
import joblib
import pandas as pd
import numpy as np

import config
from dataset_loader import DatasetLoader
from preprocessing import CatalystDataPreprocessor

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


class CatalystPredictor:
    def __init__(self):
        self.model = None
        self.preprocessor = None
        self.metrics = {}
        self.dataset_df = None
        self.target_column = None
        self.target_unit = config.DEFAULT_TARGET_UNIT
        self.catalyst_col = None
        self.load_model_and_data()

    def load_model_and_data(self):
        """Load trained regression model, preprocessor, and cleaned dataset."""
        if not config.TRAINED_MODEL_PATH.exists() or not config.PREPROCESSOR_PATH.exists():
            logger.warning("Trained model or preprocessor not found. Training model now...")
            from train_model import CatalystModelTrainer
            trainer = CatalystModelTrainer()
            trainer.train_and_compare_models()

        self.model = joblib.load(config.TRAINED_MODEL_PATH)
        self.preprocessor = CatalystDataPreprocessor.load(config.PREPROCESSOR_PATH)

        if config.METRICS_PATH.exists():
            with open(config.METRICS_PATH, "r") as f:
                self.metrics = json.load(f)

        # Load dataset
        loader = DatasetLoader()
        self.dataset_df = loader.load_dataset()
        self.target_column = loader.target_column
        self.target_unit = loader.target_unit
        self.catalyst_col = loader.catalyst_col

    def predict_all_catalysts(self) -> List[Dict[str, Any]]:
        """
        Predict hydrogen production for all unique catalysts in dataset
        using the trained ML model based on their experimental feature profiles.
        Rank catalysts strictly by model predictions without artificial bias.
        """
        df = self.dataset_df
        cat_col = self.catalyst_col
        target_col = self.target_column

        unique_catalysts = sorted(df[cat_col].unique().tolist())
        catalyst_summaries = []

        # Feature columns expected by preprocessor
        feature_cols = self.preprocessor.feature_columns
        num_cols = self.preprocessor.numerical_cols

        for cat_name in unique_catalysts:
            cat_records = df[df[cat_col] == cat_name]
            record_count = len(cat_records)

            # Experimental measured statistics
            measured_vals = cat_records[target_col].dropna().values
            measured_mean = round(float(np.mean(measured_vals)), 2) if len(measured_vals) > 0 else None
            measured_min = round(float(np.min(measured_vals)), 2) if len(measured_vals) > 0 else None
            measured_max = round(float(np.max(measured_vals)), 2) if len(measured_vals) > 0 else None
            measured_std = round(float(np.std(measured_vals)), 2) if len(measured_vals) > 0 else None

            # Construct representative experimental profile for this catalyst (median of conditions)
            rep_profile = {}
            for col in feature_cols:
                if col in num_cols:
                    rep_profile[col] = float(cat_records[col].median())
                elif col in cat_records.columns:
                    rep_profile[col] = str(cat_records[col].mode()[0])
                else:
                    rep_profile[col] = "Unknown"

            # Always ensure the catalyst name is preserved
            rep_profile[cat_col] = cat_name

            # Generate prediction using trained ML model
            rep_df = pd.DataFrame([rep_profile])
            X_trans = self.preprocessor.transform_single_or_df(rep_df)
            pred_rate = float(self.model.predict(X_trans)[0])
            pred_rate = max(round(pred_rate, 2), 0.0)

            # Support material
            support = str(cat_records["support_material"].mode()[0]) if "support_material" in cat_records.columns else "Carbon"

            # Metal loadings breakdown
            pt_wt = round(float(cat_records["pt_loading_wt_pct"].median()), 2) if "pt_loading_wt_pct" in cat_records.columns else 0.0
            ru_wt = round(float(cat_records["ru_loading_wt_pct"].median()), 2) if "ru_loading_wt_pct" in cat_records.columns else 0.0
            ni_wt = round(float(cat_records["ni_loading_wt_pct"].median()), 2) if "ni_loading_wt_pct" in cat_records.columns else 0.0
            total_metal = round(float(cat_records["total_metal_loading_wt_pct"].median()), 2) if "total_metal_loading_wt_pct" in cat_records.columns else (pt_wt + ru_wt + ni_wt)

            is_primary = (cat_name == config.PRIMARY_CANDIDATE)

            catalyst_summaries.append({
                "catalyst_name": cat_name,
                "predicted_h2_rate": pred_rate,
                "measured_h2_rate_mean": measured_mean,
                "measured_h2_rate_min": measured_min,
                "measured_h2_rate_max": measured_max,
                "measured_h2_rate_std": measured_std,
                "target_unit": self.target_unit,
                "record_count": record_count,
                "support_material": support,
                "metal_loadings": {
                    "pt_wt_pct": pt_wt,
                    "ru_wt_pct": ru_wt,
                    "ni_wt_pct": ni_wt,
                    "total_metal_wt_pct": total_metal
                },
                "is_primary_candidate": is_primary
            })

        # Rank all catalysts descending by predicted H2 rate
        catalyst_summaries.sort(key=lambda x: x["predicted_h2_rate"], reverse=True)
        total_cats = len(catalyst_summaries)

        for rank_idx, item in enumerate(catalyst_summaries, 1):
            item["ranking"] = rank_idx
            item["total_catalysts"] = total_cats

        return catalyst_summaries

    def get_best_catalyst(self) -> Dict[str, Any]:
        """
        Identify the catalyst with highest predicted hydrogen production.
        Calculate differences compared with other catalysts without hardcoding.
        """
        catalysts = self.predict_all_catalysts()
        if not catalysts:
            return {"error": "No catalyst predictions available."}

        best = catalysts[0]
        runner_up = catalysts[1] if len(catalysts) > 1 else None

        # Find benchmark Pt/C
        pt_benchmark = next((c for c in catalysts if c["catalyst_name"] == "Pt/C"), None)

        # Average predicted rate across all catalysts
        all_rates = [c["predicted_h2_rate"] for c in catalysts]
        avg_rate = round(float(np.mean(all_rates)), 2)

        diff_vs_runner_up = None
        pct_diff_vs_runner_up = None
        if runner_up:
            diff_vs_runner_up = round(best["predicted_h2_rate"] - runner_up["predicted_h2_rate"], 2)
            pct_diff_vs_runner_up = round((diff_vs_runner_up / runner_up["predicted_h2_rate"]) * 100, 1) if runner_up["predicted_h2_rate"] > 0 else 0.0

        diff_vs_pt_benchmark = None
        pct_diff_vs_pt_benchmark = None
        if pt_benchmark and pt_benchmark["catalyst_name"] != best["catalyst_name"]:
            diff_vs_pt_benchmark = round(best["predicted_h2_rate"] - pt_benchmark["predicted_h2_rate"], 2)
            pct_diff_vs_pt_benchmark = round((diff_vs_pt_benchmark / pt_benchmark["predicted_h2_rate"]) * 100, 1)

        diff_vs_avg = round(best["predicted_h2_rate"] - avg_rate, 2)
        pct_diff_vs_avg = round((diff_vs_avg / avg_rate) * 100, 1) if avg_rate > 0 else 0.0

        return {
            "catalyst_name": best["catalyst_name"],
            "predicted_h2_rate": best["predicted_h2_rate"],
            "measured_h2_rate_mean": best["measured_h2_rate_mean"],
            "target_unit": self.target_unit,
            "ranking": best["ranking"],
            "total_catalysts": best["total_catalysts"],
            "support_material": best["support_material"],
            "metal_loadings": best["metal_loadings"],
            "difference_vs_runner_up": diff_vs_runner_up,
            "pct_difference_vs_runner_up": pct_diff_vs_runner_up,
            "runner_up_name": runner_up["catalyst_name"] if runner_up else None,
            "difference_vs_pt_benchmark": diff_vs_pt_benchmark,
            "pct_difference_vs_pt_benchmark": pct_diff_vs_pt_benchmark,
            "difference_vs_average": diff_vs_avg,
            "pct_difference_vs_average": pct_diff_vs_avg,
            "average_all_catalysts_rate": avg_rate,
            "scientific_rationale": (
                f"Model predicts {best['catalyst_name']} produces {best['predicted_h2_rate']} {self.target_unit}, "
                f"which is {pct_diff_vs_avg}% above the dataset average ({avg_rate} {self.target_unit}). "
                f"Selection is strictly driven by regression weights on multi-metal synergy and reaction kinetics."
            )
        }

    def get_catalyst_details(self, catalyst_name: str) -> Optional[Dict[str, Any]]:
        """
        Detailed information for a specific catalyst when clicked on the dashboard.
        """
        all_catalysts = self.predict_all_catalysts()
        target_cat = next((c for c in all_catalysts if c["catalyst_name"] == catalyst_name), None)
        if not target_cat:
            return None

        df = self.dataset_df
        cat_col = self.catalyst_col
        cat_records = df[df[cat_col] == catalyst_name]

        # Extract experimental records table
        records_table = []
        for _, row in cat_records.iterrows():
            records_table.append({
                "pt_wt": round(float(row.get("pt_loading_wt_pct", 0.0)), 2),
                "ru_wt": round(float(row.get("ru_loading_wt_pct", 0.0)), 2),
                "ni_wt": round(float(row.get("ni_loading_wt_pct", 0.0)), 2),
                "support": str(row.get("support_material", "Carbon")),
                "bet_area": round(float(row.get("bet_surface_area_m2_g", 0.0)), 1),
                "particle_size": round(float(row.get("avg_particle_size_nm", 0.0)), 2),
                "temperature": float(row.get("reaction_temperature_c", 25.0)),
                "measured_rate": round(float(row.get(self.target_column, 0.0)), 2),
                "unit": self.target_unit,
                "doi": str(row.get("doi_reference", "N/A"))
            })

        # Special evaluation for Pt-Ru-Ni/C
        candidate_analysis = None
        if catalyst_name == config.PRIMARY_CANDIDATE:
            if len(cat_records) > 0:
                candidate_analysis = {
                    "is_present_in_dataset": True,
                    "records_found": len(cat_records),
                    "status_note": (
                        f"Pt-Ru-Ni/C is represented in the dataset with {len(cat_records)} real experimental records. "
                        f"Its ranking (#{target_cat['ranking']} of {target_cat['total_catalysts']}) is computed strictly from "
                        f"the trained machine-learning model without artificial bonus. "
                        f"Measured mean: {target_cat['measured_h2_rate_mean']} {self.target_unit}, "
                        f"Model predicted: {target_cat['predicted_h2_rate']} {self.target_unit}."
                    )
                }
            else:
                candidate_analysis = {
                    "is_present_in_dataset": False,
                    "records_found": 0,
                    "status_note": (
                        "Pt-Ru-Ni/C has NO experimental records in this training dataset. "
                        "Its predicted value is a model extrapolation based on metal loading features. "
                        "No experimental validation is claimed."
                    )
                }

        return {
            "catalyst_name": catalyst_name,
            "ranking": target_cat["ranking"],
            "total_catalysts": target_cat["total_catalysts"],
            "predicted_h2_rate": target_cat["predicted_h2_rate"],
            "measured_h2_rate_mean": target_cat["measured_h2_rate_mean"],
            "measured_h2_rate_min": target_cat["measured_h2_rate_min"],
            "measured_h2_rate_max": target_cat["measured_h2_rate_max"],
            "measured_h2_rate_std": target_cat["measured_h2_rate_std"],
            "target_unit": self.target_unit,
            "support_material": target_cat["support_material"],
            "metal_loadings": target_cat["metal_loadings"],
            "record_count": target_cat["record_count"],
            "experimental_records": records_table,
            "is_primary_candidate": (catalyst_name == config.PRIMARY_CANDIDATE),
            "candidate_analysis": candidate_analysis
        }

    def get_comparison_data(self) -> Dict[str, Any]:
        """
        Formatted catalyst comparison data for Chart.js bar graphs.
        Highlights the best predicted catalyst and distinctively marks Pt-Ru-Ni/C.
        """
        catalysts = self.predict_all_catalysts()
        best_name = catalysts[0]["catalyst_name"] if catalysts else None

        labels = []
        predicted_values = []
        measured_values = []
        bar_colors = []
        border_colors = []

        for cat in catalysts:
            name = cat["catalyst_name"]
            labels.append(name)
            predicted_values.append(cat["predicted_h2_rate"])
            measured_values.append(cat["measured_h2_rate_mean"])

            # Highlight best catalyst in vibrant emerald green, Pt-Ru-Ni/C in violet/indigo, others in slate blue
            if name == best_name:
                bar_colors.append("rgba(16, 185, 129, 0.85)")  # Emerald green (winner)
                border_colors.append("#059669")
            elif name == config.PRIMARY_CANDIDATE:
                bar_colors.append("rgba(139, 92, 246, 0.85)")  # Violet (investigated candidate)
                border_colors.append("#7c3aed")
            else:
                bar_colors.append("rgba(59, 130, 246, 0.70)")   # Royal blue
                border_colors.append("#2563eb")

        return {
            "labels": labels,
            "predicted_rates": predicted_values,
            "measured_rates": measured_values,
            "bar_colors": bar_colors,
            "border_colors": border_colors,
            "target_unit": self.target_unit,
            "best_catalyst": best_name,
            "primary_candidate": config.PRIMARY_CANDIDATE
        }

    def predict_custom_catalyst(self, user_input: Dict[str, Any]) -> Dict[str, Any]:
        """
        Interactive simulation tool: allows predicting H2 rate for custom formulation.
        """
        pt = float(user_input.get("pt_loading_wt_pct", 0.0))
        ru = float(user_input.get("ru_loading_wt_pct", 0.0))
        ni = float(user_input.get("ni_loading_wt_pct", 0.0))
        other = float(user_input.get("other_metal_wt_pct", 0.0))
        total_metal = pt + ru + ni + other

        temp = float(user_input.get("reaction_temperature_c", 50.0))
        bet = float(user_input.get("bet_surface_area_m2_g", 400.0))
        size = float(user_input.get("avg_particle_size_nm", 3.0))
        conc = float(user_input.get("reactant_concentration_M", 1.0))
        stirring = float(user_input.get("stirring_speed_rpm", 800.0))
        support = str(user_input.get("support_material", "Vulcan Carbon XC-72"))
        cat_name = str(user_input.get("catalyst_name", "Custom Catalyst"))

        row = {
            "catalyst_name": cat_name,
            "pt_loading_wt_pct": pt,
            "ru_loading_wt_pct": ru,
            "ni_loading_wt_pct": ni,
            "other_metal_wt_pct": other,
            "total_metal_loading_wt_pct": total_metal,
            "support_material": support,
            "bet_surface_area_m2_g": bet,
            "avg_particle_size_nm": size,
            "reaction_temperature_c": temp,
            "reactant_concentration_M": conc,
            "stirring_speed_rpm": stirring
        }

        df_custom = pd.DataFrame([row])
        X_trans = self.preprocessor.transform_single_or_df(df_custom)
        pred = float(self.model.predict(X_trans)[0])
        pred = max(round(pred, 2), 0.0)

        return {
            "catalyst_name": cat_name,
            "predicted_h2_rate": pred,
            "target_unit": self.target_unit,
            "input_parameters": row
        }
